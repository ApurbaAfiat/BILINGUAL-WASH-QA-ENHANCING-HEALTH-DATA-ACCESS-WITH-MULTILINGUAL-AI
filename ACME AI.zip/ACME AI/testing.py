from bangla_to_english import query_qa

# Define manual evaluation template for a few test queries
test_queries = [
    "২০২০ সালে সুদানে শিশু মৃত্যুর হার কত ছিল?",
    "What was the hygiene status of Sudan in 2020?",
    "সুদানে ২০১৫ থেকে ২০২০ সালের মধ্যে পানির প্রবেশাধিকার কেমন ছিল?"
]

# Run them through your QA system
for query in test_queries:
    response = query_qa(query)
    print(f"\n Query: {query}")
    print(f" Response: {response}")
    